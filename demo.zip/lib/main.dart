import 'package:flutter/material.dart';
import 'package:demo/signin.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SignUp(),
  ));
}

class SignUp extends StatelessWidget with InputValidationMixin {
  final formGlobalKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('GIFTO'),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Form(
            key: formGlobalKey,
            child: Column(
              children: [
                const SizedBox(height: 50),
                Text(
                  'Sign Up',
                  style: TextStyle(color: Colors.blue, fontWeight: FontWeight.w500, fontSize: 30),
                ),
                //const SizedBox(height: 24),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Name",
                  ),
                  validator: (name) {
                    if (name.isEmpty) return 'Enter your name';
                  },
                ),
                //const SizedBox(height: 24),
                TextFormField(
                  decoration: InputDecoration(labelText: "Email"),
                  validator: (email) {
                    if (isEmailValid(email))
                      return null;
                    else
                      return 'Enter a valid email address';
                  },
                ),
                //const SizedBox(height: 24),
                TextFormField(
                  decoration: InputDecoration(labelText: "User Name"),
                  validator: (username) {
                    if (username.isEmpty) return 'Enter a user name';
                  },
                ),
                //const SizedBox(height: 24),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Phone Number",
                  ),
                  validator: (phone) {
                    if (isValidPhoneNumber(phone))
                      return null;
                    else
                      return 'Enter your phone number';
                  },
                ),
                //const SizedBox(height: 24),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: "Password",
                  ),
                  maxLength: 6,
                  obscureText: true,
                  validator: (password) {
                    if (isPasswordValid(password))
                      return null;
                    else
                      return 'Enter a valid password';
                  },
                ),
                ElevatedButton(
                    onPressed: () {
                      if (formGlobalKey.currentState.validate()) {
                        formGlobalKey.currentState.save();
                        // use the email provided here
                      }
                    },
                    child: Text(
                      "Submit",
                      style: TextStyle(fontSize: 30),
                    )),
                const SizedBox(height: 30),
                ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => Signin()),
                      );
                    },
                    child: Text("Sign in")),
              ],
            ),
          ),
        ));
  }
}

mixin InputValidationMixin {
  bool isPasswordValid(String password) => password.length == 6;

  bool isEmailValid(String email) {
    Pattern pattern = r'^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    return regex.hasMatch(email);
  }

  bool isValidPhoneNumber(String string) {
    // Null or empty string is invalid phone number
    if (string == null || string.isEmpty) {
      return false;
    }

    // You may need to change this pattern to fit your requirement.
    // I just copied the pattern from here: https://regexr.com/3c53v
    const pattern = r'(01)[0-9]{9}$';
    final regExp = RegExp(pattern);

    if (!regExp.hasMatch(string)) {
      return false;
    }
    return true;
  }
}
